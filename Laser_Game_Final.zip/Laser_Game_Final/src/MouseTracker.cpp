//
//  MouseTracker.cpp
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 12/1/14.
//
//

#include "MouseTracker.h"

MouseTracker::MouseTracker(){
    
    grabber.setDeviceID(0);             //grab our first cam device
    grabber.setDesiredFrameRate(30);    //set framerate for cam
    grabber.initGrabber(1280, 720);      //set our incoming size
    
    image.allocate(grabber.width, grabber.height);  //allocate our CV ColorImage with w/h based off cam
    greyImage.allocate(grabber.width, grabber.height);  //same for other CV Images
    greyBackground.allocate(grabber.width, grabber.height); //same
    greyProcessed.allocate(grabber.width,grabber.height);   //same
    
    learnBackground = false;    //intially set to false
    
    maxBlobs = 1;   //maximum number of blobs and size of our ofPoint vector
    
    blobCenters.resize(maxBlobs);   //set the size or our vector based off the numbe of blobs
    
    thresholdStick = 254;
    
    screenDraw = false;

    
}

void MouseTracker::update(){
    
    grabber.update();   //pull our next frame of video
    
    image.setFromPixels(grabber.getPixelsRef());    //set our CV Color Image to have the same data as the current frame
    
    greyImage = image;  //convert our color image to grayscale
    
    //change the background comparision baseline if learnBackground is true
    if(learnBackground){
        greyBackground = greyImage;     //set the background to the current frame
        learnBackground = false;        //toggle back to false
    }
    
    greyDiff.absDiff(greyBackground, greyImage);    //do a comparison between our current background ref and current frame and store result in greyDiff
    
    greyProcessed = greyDiff;  //set our greyProcessed to be our greyDiff
    
    greyProcessed.threshold(thresholdStick);
    
    //finding our contours on our processed image with a min size of 10 and max of half our screen size, looking for 1 blob, and looking for holes
    contourFinder.findContours(greyProcessed, 40, (grabber.width*grabber.height)/2, maxBlobs, true);
    
    //iterate through our blobs and pull the centroid and store as ofPoint
    for(int i = 0; i < contourFinder.nBlobs; i++){
        blobCenters[i] = contourFinder.blobs[i].centroid;
    }

    
}

void MouseTracker::display(){
    
    
    //iterate through our blobs and draw them to the screen
    for(int i = 0; i < contourFinder.nBlobs; i++){
        //contourFinder.blobs[i].draw(0,0);
    }
    
    for(int i = 0; i < blobCenters.size(); i++){
        ofSetColor(0, 255, 0, 150);
        ofFill();
        ofCircle(blobCenters[i], 40);
    }

    
}