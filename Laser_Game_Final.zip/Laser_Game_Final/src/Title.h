//
//  Title.h
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 11/18/14.
//
//

#ifndef __Laser_Game_Final__Title__
#define __Laser_Game_Final__Title__

#include <stdio.h>
#include <ofMain.h>

#endif /* defined(__Laser_Game_Final__Title__) */

class Title{
    
public:
    Title();
    
    ofPoint startButton;
    ofPoint gameName;
    ofPoint mouse;
    
    bool gameStart; //Boolean to start the game
    
    void update();
    void display();
    void startChecker();
    
    ofImage image; //Menu assets
    ofImage gameTitle;
    ofImage menuPic;
    
};
