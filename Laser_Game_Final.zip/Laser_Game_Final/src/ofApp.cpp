#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofSetWindowShape(1280, 720);
    ofSetFrameRate(60);
    ofSetBackgroundAuto(true);
    //ofSetFullscreen(true);
    ofShowCursor();
    
    screenDraw = false;
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    if(titleScreen.gameStart == false){ //If start button has not been moused over
        
        firstGame.resetPos(); //Keeps the game resetting while the game isn't started
        titleScreen.update();
        titleScreen.startChecker();
        
        
    } else if(titleScreen.gameStart == true){ //If start button has been moused over
        
        firstGame.update();
        firstGame.gameOverCheck();
        
    }
    
    if(firstGame.gameOver == true){ //If mouse has gone outside the game box, restart the game.
        
        titleScreen.gameStart = false;
        firstGame.gameOver = false;
        
    }
    
    tracker.update();
    
    titleScreen.mouse = ofPoint(tracker.blobCenters[0].x, tracker.blobCenters[0].y); //Controlling the game with the laser
    firstGame.mouse = ofPoint(tracker.blobCenters[0].x, tracker.blobCenters[0].y);
    
    //titleScreen.mouse = ofPoint(ofGetMouseX(),ofGetMouseY()); //Controlling the game with the mouse
    //firstGame.mouse = ofPoint(ofGetMouseX(),ofGetMouseY());
    
    cout<<tracker.screenDraw<<endl;
    
    }

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(255,255,255);
    
    if (titleScreen.gameStart == false){ //If the game has not been started yet display the Title screen
        
        titleScreen.display();
        
    } else if(titleScreen.gameStart == true){ //If the game has been started then play the game
        
        firstGame.display();
        
    }
    
    if(screenDraw == true){
        tracker.image.draw(0,0);    //draw our color image
        ofRect(0,0,50,50);
        ofRect(ofGetScreenWidth()-50, 0,50,50);
        ofRect(0,ofGetScreenHeight()-150,50,50);
        ofRect(ofGetScreenWidth()-50,ofGetScreenHeight()-150,50,50);
        
    }
    tracker.display();
    
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

    if(key == ' '){
        screenDraw =! screenDraw;
    }
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
