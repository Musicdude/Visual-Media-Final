//
//  GameOne.h
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 11/20/14.
//
//

#ifndef __Laser_Game_Final__GameOne__
#define __Laser_Game_Final__GameOne__

#include <stdio.h>
#include <ofMain.h>

#endif /* defined(__Laser_Game_Final__GameOne__) */

class GameOne{
    
public:
    GameOne();
    
    ofPoint mouse;
    ofPoint movingBox1;
    ofPoint movingBox2;
    ofPoint movingBox3;
    ofPoint movingBox4;
    
    ofImage background;
    ofImage platform1;
    ofImage platform2;
    ofImage platform3;
    ofImage platform4;
    
    int timer;
    int elapsed; //How much time has passed since the game has started
    int xMove1; //How much the platforms will move on the x axis
    int xMove2;
    int yMove1; //How much the platforms will move on the y axis
    int yMove2;
    int squareWidth;
    int squareHeight;
    
    bool gameOver; //loss condition
    bool victory; //win condition
    bool boxMover1; //Moves all of the boxes left or right
    bool boxMover2;
    bool boxMover3;
    bool boxMover4;
    bool started; //If game has been started
    bool reset; //When game is reset
    bool up; //Boolean for edge loop
    bool down;
    
    void update();
    void display();
    void gameOverCheck();
    void resetPos();
    void edgeChecks();
    void speedIncrease();
    
};
