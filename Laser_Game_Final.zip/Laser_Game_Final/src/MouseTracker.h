//
//  MouseTracker.h
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 12/1/14.
//
//

#ifndef __Laser_Game_Final__MouseTracker__
#define __Laser_Game_Final__MouseTracker__

#include <stdio.h>
#include <ofMain.h>
#include <ofxOpenCv.h>

#endif /* defined(__Laser_Game_Final__MouseTracker__) */

class MouseTracker{
    
public:
    MouseTracker();
    
    void update();
    void display();
    void screenDrawing();
    
    void keyPressed(int key);
    
    ofVideoGrabber grabber; //VideoGrabber for cam input
    
    ofxCvColorImage image;      //CV ColorImage for our cam input
    ofxCvGrayscaleImage greyImage;  //CV GreyscaleImage for conversion of our cam
    ofxCvGrayscaleImage greyBackground; //CV GreyscaleImage to store the background
    ofxCvGrayscaleImage greyDiff;       //CV GreyscaleImage to store the difference between the greyImage and greyBackground aka bk removal
    ofxCvGrayscaleImage greyProcessed;  //CV GreyscaleImage that is preprocessed prior to blob detection
    
    bool learnBackground;   //bool to set whether or not to look for a new background plate
    bool screenDraw; //Boolean to draw the camera feel
    
    ofxCvContourFinder contourFinder;   //object for handling contour finding aka blobs
    
    vector <ofPoint> blobCenters;   //ofPoints vector for our Blob centroids
    int maxBlobs;   //maximum number of blobs
    int thresholdStick;

    
};
