//
//  Title.cpp
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 11/18/14.
//
//

#include "Title.h"

Title::Title(){
    
    image.loadImage("Start.jpg");
    gameTitle.loadImage("GameName.jpg");
    menuPic.loadImage("Menu.jpg");
    
    startButton = ofPoint(ofGetWidth()/2, ofGetHeight()/1.5 + 50);
    gameName = ofPoint(ofGetWidth()/3 + 25, ofGetHeight()/2 - 250);
    
    gameStart = false;
    
}

void Title::update(){
    
    
}

void Title::display(){
    
    menuPic.draw(0,0,1280,720);
    ofSetColor(255,100,100);
    ofFill();
    image.draw(startButton, 300, 100);
    gameTitle.draw(gameName, 600, 200);
    
    
}

void Title::startChecker(){
    
    if(mouse.x >= startButton.x && mouse.x <= startButton.x + 300){
        if(mouse.y >= startButton.y && mouse.y <= startButton.y + 100){
            gameStart = true;
        }
    }

}