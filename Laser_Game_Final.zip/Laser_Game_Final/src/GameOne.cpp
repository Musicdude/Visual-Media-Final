//
//  GameOne.cpp
//  Laser_Game_Final
//
//  Created by Ryan Duarte on 11/20/14.
//
//

#include "GameOne.h"

GameOne::GameOne(){

    movingBox1 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 240);
    movingBox2 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 480);
    movingBox3 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 720);
    movingBox4 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 960);
    
    gameOver = false;
    boxMover1 = false;
    boxMover2 = false;
    boxMover3 = true;
    boxMover4 = true;
    down = true;
    up = false;
    victory = false;
    
    background.loadImage("BlackHole.jpg");
    platform1.loadImage("Platform.jpg");
    platform2.loadImage("Platform.jpg");
    platform3.loadImage("Platform.jpg");
    platform4.loadImage("Platform.jpg");
    
    timer = 0;
    
    xMove1 = 0;
    xMove2 = 0;
    yMove1 = 0;
    yMove2 = 0;
    
    timer = ofGetElapsedTimeMillis();
    elapsed = 0;
    
    squareWidth = 320;
    squareHeight = 240;
    
    started = false;
    
}

void GameOne::update(){
    
    elapsed = ofGetElapsedTimeMillis() - timer; //Creates the timer that will count up every milisecond the game is running
    
    cout<<elapsed<<endl;
    
    movingBox1.y += yMove1; //Sets all of the boxes to move on the y axis as fast as yMove tells it to
    movingBox2.y += yMove2;
    movingBox3.y += yMove1;
    movingBox4.y += yMove2;
    
    edgeChecks();
    speedIncrease();
    
}

void GameOne::display(){
    
    background.draw(0,0,1280,720);
    
    ofSetColor(0,255,50);
    ofFill();
    platform1.draw(movingBox1, squareWidth, squareHeight); //Makes the box move around with the movingBox1 point
    platform2.draw(movingBox2, squareWidth, squareHeight); //Makes the box move around with the movingBox2 point
    platform3.draw(movingBox3, squareWidth, squareHeight); //Makes the box move around with the movingBox3 point
    platform4.draw(movingBox4, squareWidth, squareHeight); //Makes the box move around with the movingBox4 point

    
}

void GameOne::gameOverCheck(){ //Function that checks for game over
    
    if(mouse.x > movingBox1.x + squareWidth || mouse.x < movingBox1.x || mouse.y > movingBox1.y + squareHeight || mouse.y < movingBox1.y){
        if(mouse.x > movingBox2.x + squareWidth || mouse.x < movingBox2.x || mouse.y > movingBox2.y + squareHeight || mouse.y < movingBox2.y){
            if(mouse.x > movingBox3.x + squareWidth || mouse.x < movingBox3.x || mouse.y > movingBox3.y + squareHeight || mouse.y < movingBox3.y){
                if(mouse.x > movingBox4.x + squareWidth || mouse.x < movingBox4.x || mouse.y > movingBox4.y + squareHeight || mouse.y < movingBox4.y){

                    gameOver = true; //If the mouse goes outside the boxes then game over
                    resetPos();
                }
            }
        }
    
    } else {
        
        gameOver = false;
        
    }
}

void GameOne::resetPos(){ //Function that resets all of the states in the game to their starting positions
    
    timer = ofGetElapsedTimeMillis();
    elapsed = 0;
    
    boxMover1 = true;
    boxMover2 = false;
    boxMover3 = true;
    boxMover4 = false;
    down = true;
    up = false;
    victory = false;
    
    squareWidth = 320;
    squareHeight = 240;
    
    movingBox1 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 240);
    movingBox2 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 480);
    movingBox3 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 720);
    movingBox4 = ofPoint(ofGetWidth()/2 - 150, ofGetHeight() - 960);
    
}

void GameOne::speedIncrease(){ //This is the function that increases the difficulty of the game as time goes on
    
    if(elapsed >= 0 && elapsed <= 5000){ //As the timer increases, so does the difficulty
        
        xMove1 = 0; //Speed at which the boxes move left and right
        xMove2 = 0;
        yMove1 = 0; //Speed at which the boxes move down
        yMove2 = 0;
        
    }
    
    if(elapsed > 5000 && elapsed <= 13000){
        
        xMove1 = 2;
        xMove2 = 2;
        yMove1 = .5;
        yMove2 = .5;
        
    }
    if(elapsed > 13000 && elapsed <= 21000){
        
        xMove1 = 4;
        xMove2 = 4;
        yMove1 = 1;
        yMove2 = 1;
        
    }
    if(elapsed > 21000 && elapsed <= 23270){
        
        xMove1 = 4;
        xMove2 = 4;
        yMove1 = 1;
        yMove2 = 1;
        squareWidth -= 1; //Variables to make the squares grow and shrink
        squareHeight -= 1;
        
    }
    if(elapsed > 23270 && elapsed <= 25250){
        
        xMove1 = 4;
        xMove2 = 4;
        yMove1 = 1;
        yMove2 = 1;
        squareWidth += 1;
        squareHeight += 1;
        
    }
    if(elapsed > 25250 && elapsed <= 28500){
        
        xMove1 = 0;
        xMove2 = 0;
        yMove1 = 1;
        yMove2 = 1;
        squareWidth -= 0;
        squareHeight -= 0;
        
    }
    if(elapsed > 28500 && elapsed <= 31000){
        
        xMove1 = 4;
        xMove2 = 4;
        yMove1 = 1;
        yMove2 = 1;
        if(squareWidth < 320){
        squareWidth += 1;
        }
        if(squareHeight < 240){
        squareHeight += 1;
        }
        
    }
    if(elapsed > 31000 && elapsed <= 42000){
        
        xMove1 = 4;
        xMove2 = 4;
        yMove1 = -1;
        yMove2 = -1;
        
    }
    if(elapsed > 42000 && elapsed <= 45000){
        
        xMove1 = 6;
        xMove2 = 6;
        yMove1 = 0;
        yMove2 = 0;
        
    }
    if(elapsed > 45000 && elapsed <= 50000){
        
        xMove1 = 6;
        xMove2 = 6;
        yMove1 = 2;
        yMove2 = 2;
        
    }
    if(elapsed > 50000 && elapsed <= 54000){
        if(movingBox1.x == ofGetWidth()/2 - 150){
            xMove1 = 0;
            xMove2 = 0;
        }
    }
    if(elapsed > 54000 && elapsed <= 64000){
        
        xMove1 = 6;
        xMove2 = 6;
        yMove1 = 2;
        yMove2 = -2;
        
        down = false;
        up = true;
    }
    if(elapsed > 66000){
        //if(movingBox1.x >= ofGetWidth()/2 - 150 && movingBox1.x <= ofGetWidth()/2 - 156){
            resetPos();
        //}
    }

    
}

void GameOne::edgeChecks(){
    
    if(down == true){
        if(movingBox1.y > 720){ //Sends the boxes above the screen when the fall off the bottom
            movingBox1.y = - 240;
        }
        if(movingBox2.y > 720){
            movingBox2.y = -240;
        }
        if(movingBox3.y > 720){
            movingBox3.y = -240;
        }
        if(movingBox4.y > 720){
            movingBox4.y = -240;
        }
    } else if(up == true){
        if(movingBox1.y > 720){ //Sends the boxes above the screen when the fall off the bottom
            movingBox1.y = - 240;
        }
        if(movingBox2.y < -240){
            movingBox2.y = 720;
        }
        if(movingBox3.y > 720){
            movingBox3.y = -240;
        }
        if(movingBox4.y < -240){
            movingBox4.y = 720;
        }
 
    }
    
    if(movingBox1.x >= ofGetWidth() - 300){ //Changes booleans whent he box1 reached the end of the screen
        
        boxMover1 = false;
        
    } else if(movingBox1.x <= 0){
        
        boxMover1 = true;
        
    }
    
    if(boxMover1 == false){ //Moves the box1 from the left to the right
        
        movingBox1.x -= xMove1;
        
    } else if(boxMover1 == true){
        
        movingBox1.x += xMove1;
        
    }
    
    if(movingBox2.x >= ofGetWidth() - 300){ //Changes booleans whent he box2 reached the end of the screen
        
        boxMover2 = false;
        
    } else if(movingBox2.x <= 0){
        
        boxMover2 = true;
        
    }
    
    if(boxMover2 == false){ //Moves the box2 from the left to the right
        
        movingBox2.x -= xMove2;
        
    } else if(boxMover2 == true){
        
        movingBox2.x += xMove2;
        
    }
    
    if(movingBox3.x >= ofGetWidth() - 300){ //Changes booleans whent he box3 reached the end of the screen
        
        boxMover3 = false;
        
    } else if(movingBox3.x <= 0){
        
        boxMover3 = true;
        
    }
    
    if(boxMover3 == false){ //Moves the box3 from the left to the right
        
        movingBox3.x -= xMove1;
        
    } else if(boxMover3 == true){
        
        movingBox3.x += xMove1;
        
    }
    
    if(movingBox4.x >= ofGetWidth() - 300){ //Changes booleans whent he box1 reached the end of the screen
        
        boxMover4 = false;
        
    } else if(movingBox4.x <= 0){
        
        boxMover4 = true;
        
    }
    
    if(boxMover4 == false){ //Moves the box1 from the left to the right
        
        movingBox4.x -= xMove2;
        
    } else if(boxMover4 == true){
        
        movingBox4.x += xMove2;
        
    }
    
}